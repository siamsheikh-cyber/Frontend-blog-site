import { Button } from '@/components/ui/button'

export default function BlogCategory() {
    return (
        <div className="max-w-(--breakpoint-xl) mx-auto flex gap-3 flex-wrap justify-center">
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
            <Button variant="outline" className="cursor-pointer">Hello Category</Button>
        </div>

    )
}
